@echo off
cd /d "%~dp0"
powershell -sta -ExecutionPolicy Bypass -File "locker.ps1"